/* ==================================================================== */
/* Allan CORNET */
/* INRIA 2008 */
/* Template toolbox_skeleton */
/* This file is released into the public domain */
/* ==================================================================== */
int csum(double *a, double *b, double *c)
{
	*c = *a + *b;
	return 0;
}
/* ==================================================================== */
