
#ifndef _GDTIMB10_H_
#define _GDTIMB10_H_ 1

/*
	This is a header file for gd font, generated using
	bdftogd version 0.51 by Jan Pazdziora, adelton@fi.muni.cz
	from bdf font
	-Adobe-Times-Bold-R-Normal--10-100-75-75-P-57-ISO8859-1
	at Fri Feb 19 09:55:42 1999.
	The original bdf was holding following copyright:
	"Copyright (c) 1984, 1987 Adobe Systems Incorporated. All Rights Reserved. Copyright (c) 1988, 1991 Digital Equipment Corporation. All Rights Reserved."
 */


#include "gd.h"

extern gdFontPtr gdtimB10;

#endif

