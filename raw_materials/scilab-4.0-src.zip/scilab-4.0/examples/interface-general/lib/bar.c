#include "pipo.h" 

int bar(int x) 
{
  return x+3; 
}
