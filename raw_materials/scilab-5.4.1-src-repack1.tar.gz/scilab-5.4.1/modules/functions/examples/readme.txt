How to create a library of Scilab functions

See demo.sce

exec(SCI+'/modules/functions/examples/demos.sce');

A.C 
INRIA 2007