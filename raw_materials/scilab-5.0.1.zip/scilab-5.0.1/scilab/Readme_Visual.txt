----------------
Prerequirements:
----------------

* Visual Studio C++ .NET 2008 Pro
* Intel Fortran 10.1.020 (or more)

or 

* Visual Studio C++ .NET 2008 Express

Please read http://wiki.scilab.org/Compiling_Scilab_5.x_under_Windows for more informations


