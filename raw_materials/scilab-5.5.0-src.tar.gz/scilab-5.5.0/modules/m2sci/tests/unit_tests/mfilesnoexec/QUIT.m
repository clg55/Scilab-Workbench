% Test file for function quit
% Copyright INRIA
% Matlab version: 6.5.0.180913a (R13)
% V.C.

quit

