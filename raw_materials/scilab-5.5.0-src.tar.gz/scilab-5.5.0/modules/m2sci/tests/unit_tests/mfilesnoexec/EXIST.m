% Test file for function exist()
% Copyright INRIA
% Matlab version: 6.5.0.180913a (R13)
% V.C.

exist item
exist item kind
