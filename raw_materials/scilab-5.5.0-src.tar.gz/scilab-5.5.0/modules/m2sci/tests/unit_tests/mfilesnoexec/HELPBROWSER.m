% Test file for function helpbrowser
% Copyright INRIA
% Matlab version: 7.0.0.19901 (R14)
% V.C.

helpbrowser