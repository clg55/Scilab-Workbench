% Test file for function ispc()
% Copyright INRIA
% Matlab version: 7.0.0.19901 (R14)
% V.C.

ispc
tf = ispc