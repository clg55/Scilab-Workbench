% Test file for function pause
% Copyright INRIA
% Matlab version: 6.5.0.180913a (R13)
% V.C.

pause

pause on
pause off

n=10
pause(n)
pause(10)