/*
 * Scilab ( http://www.scilab.org/ ) - This file is part of Scilab
 * Copyright (C) 2007 - INRIA - Allan CORNET
 *
 * Copyright (C) 2012 - 2016 - Scilab Enterprises
 *
 * This file is hereby licensed under the terms of the GNU GPL v2.0,
 * pursuant to article 5.3.4 of the CeCILL v.2.1.
 * This file was originally licensed under the terms of the CeCILL v2.1,
 * and continues to be available under such terms.
 * For more information, see the COPYING file which you should have received
 * along with this program.
 *
 */
#ifndef __COMPLETION_GENERIC_H__
#define __COMPLETION_GENERIC_H__

/**
* completion
* @param[in] dictionary
* @param[in] size of dictionary
* @param[in] some chars of a symbol
* @param[out] size of returned strings
* @return strings found in dictionary
*/
char **completion_generic(char **dictionary, int sizedictionary,
                          const char *somechars, int *sizeArrayReturned);

#endif /* __COMPLETION_GENERIC_H__ */
/*--------------------------------------------------------------------------*/
