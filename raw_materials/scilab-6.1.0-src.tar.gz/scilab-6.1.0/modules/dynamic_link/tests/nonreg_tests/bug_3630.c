/* ============================================== */
#include "api_scilab.h"
#include "sciprint.h"
#include "Scierror.h"
/* ============================================== */
int c_interface1(scilabEnv env, int nin, scilabVar* in, int nopt, scilabOpt opt, int nout, scilabVar* out)
{
    return 0;
}
/* ============================================== */
int c_interface2(scilabEnv env, int nin, scilabVar* in, int nopt, scilabOpt opt, int nout, scilabVar* out)
{
    return 0;
}
