
A small example for the link Scilab function on Windows

demo.sce : is a Scilab script which will run the make utility
and link the function defined in tdll.c 

exec(SCI+'/modules/dynamic_link/examples/call_dll_in_scilab/demo.sce')