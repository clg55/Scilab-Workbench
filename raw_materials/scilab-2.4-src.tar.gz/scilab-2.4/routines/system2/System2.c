/* Copyright INRIA */
