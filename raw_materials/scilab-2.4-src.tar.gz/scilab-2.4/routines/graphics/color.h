
/* Copyright (C) 1998 Chancelier Jean-Philippe */

#define GREYNUMBER 17
#define DEFAULTNUMCOLORS 32
extern unsigned short default_colors[];
#define DEFAULTBLACK 0
#define DEFAULTWHITE 7
