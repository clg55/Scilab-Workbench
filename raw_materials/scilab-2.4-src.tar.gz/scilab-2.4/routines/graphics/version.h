#define VERSION "Scilab-2.4"
