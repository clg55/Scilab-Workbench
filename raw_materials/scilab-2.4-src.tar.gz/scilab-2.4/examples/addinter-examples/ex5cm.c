/* Copyright INRIA */


#include <math.h>

int fp3(x,y,z) 
     double x,y,*z;
{
  *z= cos(x+y);
}
