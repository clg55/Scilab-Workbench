launch example.prj with LabWindow CVI (checked with 8.5.0 (279))
modify paths to find scilab libraries
defines PATH
set PATH=%PATH%;"c:\Program files\scilab-5.1\bin"
build example with LabWindow CVI
launch executable (example_debug.exe or example.exe)

Allan CORNET
DIGITEO 2008