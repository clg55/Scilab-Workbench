% Test file for function beep()
% Copyright INRIA
% Matlab version: 7.0.0.19901 (R14)
% V.C.

beep
beep on
beep off
s = beep()