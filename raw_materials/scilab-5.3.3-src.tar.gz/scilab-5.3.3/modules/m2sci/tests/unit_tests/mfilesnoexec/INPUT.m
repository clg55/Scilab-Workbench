% Test file for function input()
% Copyright INRIA
% Matlab version: 6.5.0.180913a (R13)
% V.C.

user_entry = input('prompt')
user_entry = input('prompt','s')

