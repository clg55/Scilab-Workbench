% Test file for function isinteger()
% Copyright INRIA
% Matlab version: 7.0.0.19901 (R14)
% V.C.

%m2scideclare A|Unknown Unknown|Unknown|Unknown
isinteger(A)
tf = isinteger(A)