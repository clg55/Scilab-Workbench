% Test file for function clear()
% Copyright INRIA
% Matlab version: 6.5.0.180913a (R13)
% V.C.

clear
clear name
clear name1 name2 name3
clear global name
clear all
clear classes
clear functions
clear global
clear import
clear variables
clear('name1','name2','name3')

