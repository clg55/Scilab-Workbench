% Test file for function helpwin
% Copyright INRIA
% Matlab version: 7.0.0.19901 (R14)
% V.C.

helpwin
helpwin fft