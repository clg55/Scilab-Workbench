% Test file for function box()
% Copyright INRIA
% Matlab version: 6.5.1.199709 (R13) Service Pack 1
% V.C.

box on
box off
box ON
box OFF
box

%m2scideclare h|1 1|handle
box(h,'on')
box(h,'off')
box(h,'ON')
box(h,'OFF')
box(h)

