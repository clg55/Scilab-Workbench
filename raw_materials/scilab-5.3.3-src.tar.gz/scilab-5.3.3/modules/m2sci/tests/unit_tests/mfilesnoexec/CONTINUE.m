% Test file for function continue
% Copyright INRIA
% Matlab version: 6.5.0.180913a (R13)
% V.C.

continue
