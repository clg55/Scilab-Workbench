% Test file for function isnumeric()
% Copyright INRIA
% Matlab version: 7.0.0.19901 (R14)
% V.C.

%m2scideclare A|Unknown Unknown|Unknown|Unknown
isnumeric(A)
tf = isnumeric(A)