% Test file for function frewind()
% Copyright INRIA
% Matlab version: 7.0.0.19901 (R14)
% V.C.

fid=1;
frewind(fid);