% Test file for function clf
% Copyright INRIA
% Matlab version: 6.5.1.199709 (R13) Service Pack 1
% V.C.

clf
clf reset
figure_handle=clf
figure_handle1=clf('reset')