% Test file for function help()
% Copyright INRIA
% Matlab version: 6.5.0.180913a (R13)
% V.C.

help
help /
help function
help toolbox/
help toolbox/function
help syntax

