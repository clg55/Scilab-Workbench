% Test file for function eval()
% Copyright INRIA
% Matlab version: 6.5.0.180913a (R13)
% V.C.

eval('1+1')
x=eval('1+1')
eval('1+1','1+2')
x=eval('1+1','1+2')
[a,b] = eval('size(1)')


