% Test file for function feof()
% Copyright INRIA
% Matlab version: 6.5.0.180913a (R13)
% V.C.

feof(1)
status = feof(1)
