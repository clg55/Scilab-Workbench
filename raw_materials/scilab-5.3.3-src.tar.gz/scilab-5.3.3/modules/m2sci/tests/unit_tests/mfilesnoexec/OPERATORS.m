% Scilab ( http://www.scilab.org/ ) - This file is part of Scilab
% Copyright (C) 2009 - DIGITEO - Vincent COUVERT
% 
% This file must be used under the terms of the CeCILL.
% This source file is licensed as described in the file COPYING, which
% you should have received as part of this distribution.  The terms
% are also available at    
% http://www.cecill.info/licences/Licence_CeCILL_V2-en.txt

% Test file for function etime()
% Matlab version: 7.6.0.324 (R2008a)

a = 1+1;
b = 1++1;
c = 1+-1;
d = 1*+1;
e = 1/+1
f = 1*-1;
g = 1/-1
h = 1--1;
k = 1-+1;
l = 1++-+-+-2;
m = 1-1;
