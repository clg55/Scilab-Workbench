% Test file for function uigetdir
% Copyright INRIA
% Matlab version: 6.5.0.180913a (R13)
% V.C.

directory_name = uigetdir
directory_name = uigetdir('start_path')
directory_name = uigetdir('start_path','dialog_title')

