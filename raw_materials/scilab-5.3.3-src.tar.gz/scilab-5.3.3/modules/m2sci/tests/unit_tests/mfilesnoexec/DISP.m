% Test file for function disp
% Copyright INRIA
% Matlab version: 6.5.0.180913a (R13)
% V.C.

X='str'
disp(X)
