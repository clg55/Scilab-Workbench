% Test file for function blanks()
% Copyright INRIA
% Matlab version: 6.5.1.199709 (R13) Service Pack 1
% V.C.

A = ['xxx' blanks(20) 'yyy'];