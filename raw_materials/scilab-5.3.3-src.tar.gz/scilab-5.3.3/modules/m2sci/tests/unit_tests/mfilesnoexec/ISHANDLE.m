% Test file for function ishandle()
% Copyright INRIA
% Matlab version: 6.5.1.199709 (R13) Service Pack 1
% V.C.

%m2scideclare h|? ?|?|?
tf = ishandle(h)

%m2scideclare h1|? ?|Handle
tf1 = ishandle(h1)

