% Test file for function lookfor()
% Copyright INRIA
% Matlab version: 6.5.0.180913a (R13)
% V.C.

lookfor abs
lookfor abs -all

