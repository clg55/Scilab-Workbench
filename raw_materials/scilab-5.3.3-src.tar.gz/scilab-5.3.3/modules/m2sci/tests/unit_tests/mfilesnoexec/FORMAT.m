% Test file for function format()
% Copyright INRIA
% Matlab version: 6.5.0.180913a (R13)
% V.C.

format
format +
format('+')
format bank
format compact
format hex
format long
format long e
format long g
format loose
format rat
format short
format short e
format short g

