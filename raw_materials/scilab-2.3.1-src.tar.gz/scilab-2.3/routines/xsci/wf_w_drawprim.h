#define	        char_height(font) \
		((font)->max_bounds.ascent + (font)->max_bounds.descent)
