#define VERSION "Scilab-2.3"

#define DEFAULT_MES "Scilab-2.3 (May 1, 1997); Scilab Group (Inria, Enpc)"
