#include "wmen_scilab.h"

extern PrintDial ScilabPrintD;

/******************************************
 * Widgets creation 
 ******************************************/

int  ExposePrintdialogWindow(flag,colored,orientation)
     int flag,*colored,*orientation;
{
  sciprint("NOT USED in win95");
  return(0);
}








