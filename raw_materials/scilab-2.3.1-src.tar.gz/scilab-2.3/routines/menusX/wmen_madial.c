/* wmessage.c
 * Scilab 
 *   Jean-Philipe Chancelier 
 *   Bugs and mail : Scilab@inria.fr 
 */

#include "wmen_scilab.h"

int MatrixDialogWindow()
{
  sciprint("Sorry : Matdialog not implemented \r\n");
  return(FALSE);
}
