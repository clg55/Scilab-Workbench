/* Type des messages lie's a` Metanet */

#define ISIZE 8
#define DSIZE 16

#define CHARSEP '\n'
#define STRINGSEP "\n"

#define LOAD      "LOAD"
#define LOAD_S    "LOAD_S"
#define LOAD1     "LOAD1"
#define LOAD1_S   "LOAD1_S"
#define SHOWNS    "SHOWNS"
#define SHOWNS_S  "SHOWNS_S"
#define SHOWNS1   "SHOWNS1"
#define SHOWNS1_S "SHOWNS1_S"
#define SHOWP     "SHOWP"
#define SHOWP_S   "SHOWP_S"
#define SHOWP1    "SHOWP1"
#define SHOWP1_S  "SHOWP1_S"
#define ACK       "ACK"
