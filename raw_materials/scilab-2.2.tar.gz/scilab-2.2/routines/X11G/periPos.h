/*-------------BEGIN--------------------------------------------------------
---------------------------------------------------------------------------*/

 extern int  drawarc_pos_();
 extern int  fillarcs_pos_();
 extern int  drawarcs_pos_();
 extern int  fillpolyline_pos_();
 extern int  drawaxis_pos_();
 extern int  cleararea_pos_();
 extern int  clearwindow_pos_();
 extern int  xclick_pos_();
 extern int  xclick_any_pos_();
 extern int  xgetmouse_pos_();
 extern int  xend_pos_();
 extern int  fillarc_pos_();
 extern int  fillrectangle_pos_();
 extern int  scilabgcget_pos_();
 extern int  initgraphic_pos_();
 extern int  drawpolyline_pos_();
 extern int  fillpolylines_pos_();
 extern int  drawpolylines_pos_();
 extern int  drawpolymark_pos_();
 extern int  displaynumbers_pos_();
 extern int  xpause_pos_();
 extern int  drawrectangle_pos_();
 extern int  drawrectangles_pos_();
 extern int  drawsegments_pos_();
 extern int  xselgraphic_pos_();
 extern int  scilabgcset_pos_();
 extern int  SetDriver_pos_();
 extern int  displaystring_pos_();
 extern int  boundingbox_pos_();
 extern int  drawarrows_pos_(); 
 extern int  loadfamily_pos_();
/*----------------------------------END---------------------------*/
