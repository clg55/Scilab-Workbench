#define VERSION "Scilab-2.2"
