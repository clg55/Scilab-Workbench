#define VERSION "Scilab-2.2"

#define DEFAULT_MES "Scilab-2.2 (29 February 1996); Scilab Group (Inria, Enpc)"
