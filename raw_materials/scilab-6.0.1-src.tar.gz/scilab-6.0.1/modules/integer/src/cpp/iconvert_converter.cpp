#include "iconvert_converter.hxx"

iConverter* iConverter::me = nullptr;
types::Cell* iConverter::converter = nullptr;