Example of use of intersci.

Interfacing C and Fortran programs (e.g. matusr-c.c and matusr-f.f 
in src directory) with Scilab.

The interface program intmatusr.f is made by intersci from the
intmatusr.desc description file.

The interface program intmatusr.f is made by the command 
"../../intersci intmatusr".

To run a demo type exec("foobare.sce") at Scilab prompt.

make clean to remove old stuff.



