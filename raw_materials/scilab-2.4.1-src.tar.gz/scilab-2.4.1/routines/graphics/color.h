
/*------------------------------------------------------------------------
    Graphic library for 2D and 3D plotting 
    Copyright (C) 1998 Chancelier Jean-Philippe
    jpc@cergrene.enpc.fr 
 --------------------------------------------------------------------------*/

#define GREYNUMBER 17
#define DEFAULTNUMCOLORS 32
extern unsigned short default_colors[];
#define DEFAULTBLACK 0
#define DEFAULTWHITE 7
