#define VERSION "Scilab-2.4.1"
