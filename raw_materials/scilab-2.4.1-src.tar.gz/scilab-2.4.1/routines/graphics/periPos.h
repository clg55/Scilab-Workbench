/*------------------------------------------------------------------------
    Graphic library for 2D and 3D plotting 
    Copyright (C) 1998 Chancelier Jean-Philippe
    jpc@cergrene.enpc.fr 
 --------------------------------------------------------------------------*/

/*-------------BEGIN--------------------------------------------------------
---------------------------------------------------------------------------*/

 extern void  C2F(drawarcPos)();
 extern void  C2F(fillarcsPos)();
 extern void  C2F(drawarcsPos)();
 extern void  C2F(fillpolylinePos)();
 extern void  C2F(drawaxisPos)();
 extern void  C2F(clearareaPos)();
 extern void  C2F(clearwindowPos)();
 extern void  C2F(xclickPos)();
 extern void  C2F(xclick_anyPos)();
 extern void  C2F(xgetmousePos)();
 extern void  C2F(xendPos)();
 extern void  C2F(fillarcPos)();
 extern void  C2F(fillrectanglePos)();
 extern void  C2F(scilabgcgetPos)();
 extern void  C2F(initgraphicPos)();
 extern void  C2F(drawpolylinePos)();
 extern void  C2F(fillpolylinesPos)();
 extern void  C2F(drawpolylinesPos)();
 extern void  C2F(drawpolymarkPos)();
 extern void  C2F(displaynumbersPos)();
 extern void  C2F(xpausePos)();
 extern void  C2F(drawrectanglePos)();
 extern void  C2F(drawrectanglesPos)();
 extern void  C2F(drawsegmentsPos)();
 extern void  C2F(xselgraphicPos)();
 extern void  C2F(scilabgcsetPos)();
 extern void  C2F(SetDriverPos)();
 extern void  C2F(displaystringPos)();
 extern void  C2F(boundingboxPos)();
 extern void  C2F(drawarrowsPos)(); 
 extern void  C2F(loadfamilyPos)();
/*----------------------------------END---------------------------*/
