/* maximum value for sum of number of inputs and outputs ports of a given block */
#define SZ_SIZE 30
/* maximum value for sum of number of inputs and outputs of a given block */
#define TB_SIZE 500
