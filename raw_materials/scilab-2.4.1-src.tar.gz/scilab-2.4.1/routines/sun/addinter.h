
/** the first dynamic interface is at position 500+1 **/
/* Copyright INRIA */
#define DynInterfStart 500
