#include "../machine.h"

extern void cerro _PARAMS((char *str));
