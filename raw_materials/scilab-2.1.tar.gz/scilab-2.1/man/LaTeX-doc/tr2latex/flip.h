/*
This file contains the words that are placed the opposite way
in troff and TeX. Is there any more?
*/
char *flip_list[] =
{
"bar",  "dot",   "dotdot",   "hat",    "tilde",   "under",     "vec"
};
