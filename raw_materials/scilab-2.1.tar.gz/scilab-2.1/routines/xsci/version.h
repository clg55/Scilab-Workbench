
#define VERSION "Scilab-2.1"

#define DEFAULT_MES "Scilab-2.1 (10 February 1995); Scilab Group (Inria, Enpc)"
