/*-------------BEGIN--------------------------------------------------------
---------------------------------------------------------------------------*/

 extern int  drawarc_xfig_();
 extern int  drawarcs_xfig_();
 extern int  fillarea_xfig_();
 extern int  drawaxis_xfig_();
 extern int  cleararea_xfig_();
 extern int  clearwindow_xfig_();
 extern int  waitforclick_xfig_();
 extern int  xgetmouse_xfig_();
 extern int  xend_xfig_();
 extern int  drawfilledarc_xfig_();
 extern int  viderbuff_xfig_();
 extern int  drawfilledrect_xfig_();
 extern int  scilabgcget_xfig_();
 extern int  initgraphic_xfig_();
 extern int  drawpolyline_xfig_();
 extern int  drawpolylines_xfig_();
 extern int  morlpolylines_xfig_();
 extern int  drawpolymark_xfig_();
 extern int  displaynumbers_xfig_();
 extern int  xpause_xfig_();
 extern int  drawrectangle_xfig_();
 extern int  drawrectangles_xfig_();
 extern int  drawsegments_xfig_();
 extern int  xselgraphic_xfig_();
 extern int  scilabgcset_xfig_();
 extern int  SetDriver_xfig_();
 extern int  displaystring_xfig_();
 extern int  boundingbox_xfig_();
 extern int  drawarrows_xfig_(); 
 extern int  loadfamily_xfig_();
/*----------------------------------END---------------------------*/
