#define VERSION "Scilab-2.1"
