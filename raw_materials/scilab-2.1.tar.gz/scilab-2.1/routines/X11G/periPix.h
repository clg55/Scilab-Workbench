/*-------------BEGIN--------------------------------------------------------
---------------------------------------------------------------------------*/

 extern int drawarc_pix_();
 extern int drawarcs_pix_();
 extern int fillpolyline_pix_();
 extern int drawaxis_pix_();
 extern int cleararea_pix_();
 extern int clearwindow_pix_();
 extern int xclick_pix_();
 extern int xgetmouse_pix_();
 extern int xend_pix_();
 extern int fillarc_pix_();
 extern int viderbuff_pix_();
 extern int fillrectangle_pix_();
 extern int MissileGCget_pix_();
 extern int initgraphic_pix_();
 extern int drawpolyline_pix_();
 extern int fillpolylines_pix_();
 extern int drawpolylines_pix_();
 extern int drawpolymark_pix_();
 extern int displaynumbers_pix_();
 extern int xpause_pix_();
 extern int drawrectangle_pix_();
 extern int drawrectangles_pix_();
 extern int drawsegments_pix_();
 extern int xselgraphic_pix_();
 extern int MissileGCset_pix_();
 extern int SetDriver_pix_();
 extern int displaystring_pix_();
 extern int boundingbox_pix_();
 extern int drawarrows_pix_();
 extern int loadfamily_pix_();

/*---------------------END------------------------------*/


