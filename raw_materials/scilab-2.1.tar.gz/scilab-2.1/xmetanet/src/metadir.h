extern char datanet[];

extern void FindGraphNames();
extern char *graphNames[];
