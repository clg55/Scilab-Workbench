#define BEGIN 1
#define STUDY 2
#define MODIFY 3

extern void DisplayMenu();
extern void ModifyGraph();
extern void ModifyQuit();
extern void StudyQuit();

extern int menuId;
