extern XtAppContext app_con;
extern Widget drawViewport;
extern Widget frame;
extern Widget metanetDraw;
extern Widget metanetMenu;
extern Widget toplevel;
