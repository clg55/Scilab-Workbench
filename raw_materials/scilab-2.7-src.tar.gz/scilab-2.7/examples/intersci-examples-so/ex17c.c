#include "machine.h"

/*******************************************
 * simple example with sparse matrix 
 * Display of a 
 *******************************************/

int F2C(ext17)(str,a,b)
     char *str;
     float *a;
     int *b;
{ 
  /* do nothing */
}
