This files is the readme.txt for your toolbox. 

Please update this file to provide information about your toolbox: what it is doing, the author, a few words about the license...

Do NOT keep this file as it is.

See https://wiki.scilab.org/ATOMS#What_are_the_technical_expectations_.3F for more information on how to use the skeleton.