#include "pipo.h" 

int foo(int x) 
{
  return x+2; 
}
