please copy here jni.h and jni_md.h from Java 2 JDK (sun) (Windows)
