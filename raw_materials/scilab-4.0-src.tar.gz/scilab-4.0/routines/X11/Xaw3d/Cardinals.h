/* $XConsortium: Cardinals.h,v 1.6 94/04/17 20:11:57 jim Exp $ */
/*

Copyright (c) 1985, 1986, 1987  X Consortium

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL THE
X CONSORTIUM BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN
AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

Except as contained in this notice, the name of the X Consortium shall not be
used in advertising or otherwise to promote the sale, use or other dealings
in this Software without prior written authorization from the X Consortium.

*/

#ifndef _Cardinals_h
#define _Cardinals_h

#define ZERO	((Cardinal)0)
#define ONE	((Cardinal)1)
#define TWO	((Cardinal)2)
#define THREE	((Cardinal)3)
#define FOUR	((Cardinal)4)
#define FIVE	((Cardinal)5)
#define SIX	((Cardinal)6)
#define SEVEN	((Cardinal)7)
#define EIGHT	((Cardinal)8)
#define NINE	((Cardinal)9)
#define TEN	((Cardinal)10)

#endif /* _Cardinals_h */
