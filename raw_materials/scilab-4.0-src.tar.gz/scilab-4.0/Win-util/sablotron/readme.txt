Put in this directory :

sabcmd.exe
sablot.dll
js32.dll
iconv.dll

libexpat.dll

you can download sablotron (full package with iconv and js32) at http://www.gingerall.org
and libexpat.dll at http://sourceforge.net/projects/expat/

