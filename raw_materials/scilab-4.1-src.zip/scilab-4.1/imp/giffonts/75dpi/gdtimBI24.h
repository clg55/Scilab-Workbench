
#ifndef _GDTIMBI24_H_
#define _GDTIMBI24_H_ 1

/*
	This is a header file for gd font, generated using
	bdftogd version 0.51 by Jan Pazdziora, adelton@fi.muni.cz
	from bdf font
	-Adobe-Times-Bold-I-Normal--24-240-75-75-P-128-ISO8859-1
	at Fri Feb 19 10:41:01 1999.
	The original bdf was holding following copyright:
	"Copyright (c) 1984, 1987 Adobe Systems Incorporated. All Rights Reserved. Copyright (c) 1988, 1991 Digital Equipment Corporation. All Rights Reserved."
 */


#include "gd.h"

extern gdFontPtr gdtimBI24;

#endif

