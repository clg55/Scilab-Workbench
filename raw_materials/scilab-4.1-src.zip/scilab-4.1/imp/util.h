#ifndef IMP_UTIL 
#define IMP_UTIL 

#include <stdio.h> 
#include <stdlib.h> 

void read_one_line(char **buff,int *stop,FILE *fd,int *buflen);

#endif 
