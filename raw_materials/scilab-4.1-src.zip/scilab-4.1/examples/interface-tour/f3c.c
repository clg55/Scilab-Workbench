#include <math.h>

int f3c(x,y,z) 
     double x,y,*z;
{
  *z= cos(x+y);
}

