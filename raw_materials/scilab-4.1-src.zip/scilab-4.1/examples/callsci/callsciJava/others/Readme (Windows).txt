execute Make.bat to compile these examples

execute :
	Exemples.bat
	ExempleEvents.bat
	ExempleEvent2.bat


Allan CORNET

