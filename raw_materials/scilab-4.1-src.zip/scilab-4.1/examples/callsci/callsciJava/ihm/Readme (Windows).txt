execute Make.bat to compile this example

execute Test-ihm.bat to test this example

Allan CORNET

