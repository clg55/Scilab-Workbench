
#define VERSION "Scilab-2.0"

#define DEFAULT_MES "Scilab-2.0 (20 May 1994); Scilab Group (Inria, Enpc)"
