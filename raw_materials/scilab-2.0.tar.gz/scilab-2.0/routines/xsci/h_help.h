/*
 * help.h : Defs for the Help browser
 *
 * George Ferguson, ferguson@cs.rochester.edu, 23 Apr 1993.
 */

extern void initHelpActions();
extern void initHelpPanel();
extern void setHelpShellState();
