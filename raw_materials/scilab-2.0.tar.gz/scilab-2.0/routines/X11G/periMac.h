/*-------------BEGIN--------------------------------------------------------
---------------------------------------------------------------------------*/

 extern int drawarc_();
 extern int drawarcs_();
 extern int fillpolyline_();
 extern int drawaxis_();
 extern int cleararea_();
 extern int clearwindow_();
 extern int xclick_();
 extern int xend_();
 extern int fillarc_();
 extern int viderbuff_();
 extern int fillrectangle_();
 extern int MissileGCget_();
 extern int initgraphic_();
 extern int drawpolyline_();
 extern int fillpolylines_();
 extern int drawpolylines_();
 extern int drawpolymark_();
 extern int displaynumbers_();
 extern int xpause_();
 extern int drawrectangle_();
 extern int drawrectangles_();
 extern int drawsegments_();
 extern int xselgraphic_();
 extern int MissileGCset_();
 extern int SetDriver_();
 extern int displaystring_();
 extern int boundingbox_();
 extern int drawarrows_();
 extern int loadfamily_();

/*---------------------END------------------------------*/


