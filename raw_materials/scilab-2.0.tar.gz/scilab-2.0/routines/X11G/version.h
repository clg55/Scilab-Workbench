#define VERSION "Scilab-2.0"
