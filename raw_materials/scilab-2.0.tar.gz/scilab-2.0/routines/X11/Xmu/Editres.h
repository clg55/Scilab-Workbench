/* $XConsortium: Editres.h,v 1.1 91/07/30 15:28:40 rws Exp $ */

#include <X11/Xfuncproto.h>

_XFUNCPROTOBEGIN

void _XEditResCheckMessages();

_XFUNCPROTOEND
