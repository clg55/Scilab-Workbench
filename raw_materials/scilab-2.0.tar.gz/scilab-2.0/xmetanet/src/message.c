void AddMessage(description)
char *description;
{
/*  printf(description);
  printf("\n");*/
}
