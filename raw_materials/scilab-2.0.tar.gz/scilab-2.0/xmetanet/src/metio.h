#define STRLEN 1000
char Description[STRLEN];

extern void AddMessage();
extern void AddText();
extern void MetanetAlert();
extern int MetanetChoose();
extern int MetanetDialog();
extern int MetanetDialogs();
extern int MetanetYesOrNo();
