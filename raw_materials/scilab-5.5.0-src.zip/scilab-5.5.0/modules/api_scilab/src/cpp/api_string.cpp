/*
 * Scilab ( http://www.scilab.org/ ) - This file is part of Scilab
 * Copyright (C) 2009 - DIGITEO - Antoine ELIAS
 * Copyright (C) 2009-2011 - DIGITEO - Allan CORNET
 *
 * This file must be used under the terms of the CeCILL.
 * This source file is licensed as described in the file COPYING, which
 * you should have received as part of this distribution.  The terms
 * are also available at
 * http://www.cecill.info/licences/Licence_CeCILL_V2.1-en.txt
 *
 * Please note that piece of code will be rewrited for the Scilab 6 family
 * However, the API (profile of the functions in the header files) will be
 * still available and supported in Scilab 6.
 */

/*--------------------------------------------------------------------------*/
#include <string.h>

#include "charEncoding.h"
#include "MALLOC.h"
#include "api_scilab.h"
#include "api_internal_common.h"
#include "api_internal_string.h"
#include "call_scilab.h"
#include "localization.h"

extern "C"
{
#include "code2str.h"
#include "freeArrayOfString.h"
};
/*--------------------------------------------------------------------------*/

/*******************************/
/*   string matrix functions   */
/*******************************/

SciErr getMatrixOfString(void* _pvCtx, int* _piAddress, int* _piRows, int* _piCols, int* _piLength, char** _pstStrings)
{
    SciErr sciErr = sciErrInit();
    int *piOffset = NULL;
    int *piData = NULL;
    int iType = 0;

    if (_piAddress == NULL)
    {
        addErrorMessage(&sciErr, API_ERROR_INVALID_POINTER, _("%s: Invalid argument address"), "getMatrixOfString");
        return sciErr;
    }

    sciErr = getVarType(_pvCtx, _piAddress, &iType);
    if (sciErr.iErr)
    {
        addErrorMessage(&sciErr, API_ERROR_GET_STRING, _("%s: Unable to get argument #%d"), "getMatrixOfString", getRhsFromAddress(_pvCtx, _piAddress));
        return sciErr;
    }

    if (iType != sci_strings)
    {
        addErrorMessage(&sciErr, API_ERROR_INVALID_TYPE, _("%s: Invalid argument type, %s expected"), "getMatrixOfString", _("string matrix"));
        return sciErr;
    }

    sciErr = getVarDimension(_pvCtx, _piAddress, _piRows, _piCols);
    if (sciErr.iErr)
    {
        addErrorMessage(&sciErr, API_ERROR_GET_STRING, _("%s: Unable to get argument #%d"), "getMatrixOfString", getRhsFromAddress(_pvCtx, _piAddress));
        return sciErr;
    }

    if (_piLength == NULL)
    {
        return sciErr;
    }

    piOffset = _piAddress + 4;

    //non cummulative length
    for (int i = 0 ; i < *_piRows **_piCols ; i++)
    {
        _piLength[i] = piOffset[i + 1] - piOffset[i];
    }

    if (_pstStrings == NULL || *_pstStrings == NULL)
    {
        return sciErr;
    }

    piData = piOffset + *_piRows **_piCols + 1;

    int sum = 0;
    for (int i = 0 ; i < *_piRows **_piCols ; i++)
    {
        if (_pstStrings[i] == NULL)
        {
            addErrorMessage(&sciErr, API_ERROR_INVALID_SUBSTRING_POINTER, _("%s: Invalid argument address"), "getMatrixOfString");
            return sciErr;
        }
        code2str(&_pstStrings[i], piData + sum, _piLength[i]);
        sum += _piLength[i];
        _pstStrings[i][_piLength[i]] = 0;
    }
    return sciErr;
}
/*--------------------------------------------------------------------------*/
SciErr createMatrixOfString(void* _pvCtx, int _iVar, int _iRows, int _iCols, const char* const * _pstStrings)
{
    int iNewPos = Top - Rhs + _iVar;
    int iAddr = *Lstk(iNewPos);
    int iTotalLen = 0;
    int *piAddr = NULL;

    //return empty matrix
    if (_iRows == 0 && _iCols == 0)
    {
        double dblReal = 0;
        SciErr sciErr = createMatrixOfDouble(_pvCtx, _iVar, 0, 0, &dblReal);
        if (sciErr.iErr)
        {
            addErrorMessage(&sciErr, API_ERROR_CREATE_EMPTY_MATRIX, _("%s: Unable to create variable in Scilab memory"), "createEmptyMatrix");
        }
        return sciErr;
    }

    getNewVarAddressFromPosition(_pvCtx, iNewPos, &piAddr);

    SciErr sciErr = fillMatrixOfString(_pvCtx, piAddr, _iRows, _iCols, _pstStrings, &iTotalLen);
    if (sciErr.iErr)
    {
        addErrorMessage(&sciErr, API_ERROR_CREATE_STRING, _("%s: Unable to create variable in Scilab memory"), "createMatrixOfString");
        return sciErr;
    }

    updateInterSCI(_iVar, '$', iAddr, sadr(iadr(iAddr) + 5 + _iRows * _iCols));
    updateLstk(iNewPos, sadr(iadr(iAddr) + 5 + _iRows * _iCols + !((_iRows * _iCols) % 2)), (iTotalLen + 1) / (sizeof(double) / sizeof(int)));
    return sciErr;
}
/*--------------------------------------------------------------------------*/
SciErr fillMatrixOfString(void* _pvCtx, int* _piAddress, int _iRows, int _iCols, const char* const* _pstStrings, int* _piTotalLen)
{
    SciErr sciErr = sciErrInit();
    int* piOffset = NULL;
    int* piData   = NULL;
    int iOffset   = 0;
    int iTotalSize = 0;
    int iMemSize = 0;
    int iFreeSpace = iadr(*Lstk(Bot)) - (iadr(*Lstk(Top)));

    for (int i = 0; i < _iRows * _iCols; i++)
    {
        iTotalSize = iTotalSize + (int)strlen(_pstStrings[i]) + 1;
    }

    iMemSize = iTotalSize + 2;

    if (iMemSize > iFreeSpace)
    {
        addStackSizeError(&sciErr, ((StrCtx*)_pvCtx)->pstName, iMemSize);
        return sciErr;
    }

    _piAddress[0] = sci_strings;
    _piAddress[1] = _iRows;
    _piAddress[2] = _iCols;
    _piAddress[3] = 0; //always 0

    piOffset  = _piAddress + 4;
    piOffset[0] = 1; //Always 1
    piData    = piOffset + _iRows * _iCols + 1;

    if (_pstStrings == NULL)
    {
        addErrorMessage(&sciErr, API_ERROR_INVALID_POINTER, _("%s: Invalid argument address"), "fillMatrixOfString");
        return sciErr;
    }

    for (int i = 0 ; i < _iRows * _iCols ; i++)
    {
        if (_pstStrings[i] == NULL)
        {
            addErrorMessage(&sciErr, API_ERROR_INVALID_SUBSTRING_POINTER, _("%s: Invalid argument address"), "getMatrixOfString");
            return sciErr;
        }

        int iLen = (int)strlen(_pstStrings[i]);
        str2code(piData + iOffset, &_pstStrings[i]);
        iOffset += iLen;
        piData[iOffset] = 0;
        piOffset[i + 1] = piOffset[i] + iLen;
    }

    *_piTotalLen  = piOffset[_iRows * _iCols] - 1;
    return sciErr;
}
/*--------------------------------------------------------------------------*/
SciErr createNamedMatrixOfString(void* _pvCtx, const char* _pstName, int _iRows, int _iCols, const char* const* _pstStrings)
{
    SciErr sciErr = sciErrInit();
    int iVarID[nsiz];
    int iSaveRhs = Rhs;
    int iSaveTop = Top;
    int *piAddr = NULL;
    int iTotalLen = 0;

    //return named empty matrix
    if (_iRows == 0 && _iCols == 0)
    {
        double dblReal = 0;
        sciErr = createNamedMatrixOfDouble(_pvCtx, _pstName, 0, 0, &dblReal);
        if (sciErr.iErr)
        {
            addErrorMessage(&sciErr, API_ERROR_CREATE_NAMED_EMPTY_MATRIX, _("%s: Unable to create variable in Scilab memory"), "createNamedEmptyMatrix");
        }
        return sciErr;
    }

    if (!checkNamedVarFormat(_pvCtx, _pstName))
    {
        addErrorMessage(&sciErr, API_ERROR_INVALID_NAME, _("%s: Invalid variable name: %s."), "createNamedMatrixOfString", _pstName);
        return sciErr;
    }

    C2F(str2name)(_pstName, iVarID, (int)strlen(_pstName));
    Top = Top + Nbvars + 1;

    getNewVarAddressFromPosition(_pvCtx, Top, &piAddr);

    //write matrix information
    sciErr = fillMatrixOfString(_pvCtx, piAddr, _iRows, _iCols, _pstStrings, &iTotalLen);
    if (sciErr.iErr)
    {
        addErrorMessage(&sciErr, API_ERROR_CREATE_NAMED_STRING, _("%s: Unable to create %s named \"%s\""), "createNamedMatrixOfString", _("matrix of string"), _pstName);
        return sciErr;
    }

    //update "variable index"

    updateLstk(Top, sadr(iadr(*Lstk(Top)) + 5 + _iRows * _iCols), iTotalLen);

    Rhs = 0;
    //Add name in stack reference list
    createNamedVariable(iVarID);

    Top = iSaveTop;
    Rhs = iSaveRhs;
    return sciErr;
}
/*--------------------------------------------------------------------------*/
SciErr readNamedMatrixOfString(void* _pvCtx, const char* _pstName, int* _piRows, int* _piCols, int* _piLength, char** _pstStrings)
{
    int* piAddr = NULL;

    SciErr sciErr = getVarAddressFromName(_pvCtx, _pstName, &piAddr);
    if (sciErr.iErr)
    {
        addErrorMessage(&sciErr, API_ERROR_READ_NAMED_STRING, _("%s: Unable to get variable \"%s\""), "readNamedMatrixOfString", _pstName);
        return sciErr;
    }

    sciErr = getMatrixOfString(_pvCtx, piAddr, _piRows, _piCols, _piLength, _pstStrings);
    if (sciErr.iErr)
    {
        addErrorMessage(&sciErr, API_ERROR_READ_NAMED_STRING, _("%s: Unable to get variable \"%s\""), "readNamedMatrixOfString", _pstName);
        return sciErr;
    }

    return sciErr;
}
/*--------------------------------------------------------------------------*/
SciErr getMatrixOfWideString(void* _pvCtx, int* _piAddress, int* _piRows, int* _piCols, int* _piwLength, wchar_t** _pwstStrings)
{
    SciErr sciErr = sciErrInit();
    int iType = 0;
    char **pstStrings = NULL;
    int *piLenStrings = NULL;
    int strSize = 0;

    if (_piAddress == NULL)
    {
        addErrorMessage(&sciErr, API_ERROR_INVALID_POINTER, _("%s: Invalid argument address"), "getMatrixOfWideString");
        return sciErr;
    }

    sciErr = getVarType(_pvCtx, _piAddress, &iType);
    if (sciErr.iErr)
    {
        addErrorMessage(&sciErr, API_ERROR_GET_WIDE_STRING, _("%s: Unable to get argument #%d"), "getMatrixOfWideString", getRhsFromAddress(_pvCtx, _piAddress));
        return sciErr;
    }

    if (iType != sci_strings)
    {
        addErrorMessage(&sciErr, API_ERROR_INVALID_TYPE, _("%s: Invalid argument type, %s expected"), "getMatrixOfWideString", _("string matrix"));
        return sciErr;
    }

    sciErr = getVarDimension(_pvCtx, _piAddress, _piRows, _piCols);
    if (sciErr.iErr)
    {
        addErrorMessage(&sciErr, API_ERROR_GET_WIDE_STRING, _("%s: Unable to get argument #%d"), "getMatrixOfWideString", getRhsFromAddress(_pvCtx, _piAddress));
        return sciErr;
    }

    if (_piwLength == NULL)
    {
        return sciErr;
    }

    strSize = (*_piRows **_piCols);
    piLenStrings = (int*)MALLOC(sizeof(int) * strSize);

    // get length UTF size
    sciErr = getMatrixOfString(_pvCtx, _piAddress, _piRows, _piCols, piLenStrings, pstStrings);
    if (sciErr.iErr)
    {
        addErrorMessage(&sciErr, API_ERROR_GET_WIDE_STRING, _("%s: Unable to get argument #%d"), "getMatrixOfWideString", getRhsFromAddress(_pvCtx, _piAddress));
        if (piLenStrings)
        {
            FREE(piLenStrings);
            piLenStrings = NULL;
        }
        return sciErr;
    }

    pstStrings = (char**)MALLOC(sizeof(char*) * strSize);
    memset(pstStrings, 0x00, sizeof(char*) * strSize);

    for (int i = 0; i < strSize; i++)
    {
        pstStrings[i] = (char*)MALLOC(sizeof(char) * (piLenStrings[i] + 1));
    }

    // get strings UTF format
    sciErr = getMatrixOfString(_pvCtx, _piAddress, _piRows, _piCols, piLenStrings, pstStrings);
    if (sciErr.iErr)
    {
        addErrorMessage(&sciErr, API_ERROR_GET_WIDE_STRING, _("%s: Unable to get argument #%d"), "getMatrixOfWideString", getRhsFromAddress(_pvCtx, _piAddress));
        if (piLenStrings)
        {
            FREE(piLenStrings);
            piLenStrings = NULL;
        }
        freeArrayOfString(pstStrings, strSize);
        return sciErr;
    }

    for (int i = 0; i < (*_piRows **_piCols); i++)
    {
        wchar_t* wString = to_wide_string(pstStrings[i]);
        if (wString)
        {
            _piwLength[i] = (int)wcslen(wString);
            FREE(wString);
            wString = NULL;
        }
        else
        {
            _piwLength[i] = 0;
            addErrorMessage(&sciErr, API_ERROR_GET_WIDE_STRING, _("%s: Unable to convert to wide string #%d"), "getMatrixOfWideString", getRhsFromAddress(_pvCtx, _piAddress));
            if (piLenStrings)
            {
                FREE(piLenStrings);
                piLenStrings = NULL;
            }
            freeArrayOfString(pstStrings, strSize);
            return sciErr;
        }
    }

    if ( (_pwstStrings == NULL) || (*_pwstStrings == NULL) )
    {
        if (piLenStrings)
        {
            FREE(piLenStrings);
            piLenStrings = NULL;
        }
        freeArrayOfString(pstStrings, strSize);
        return sciErr;
    }

    for (int i = 0; i < (*_piRows **_piCols); i++)
    {
        if (pstStrings[i])
        {
            wchar_t *wcstring = to_wide_string(pstStrings[i]);
            if (wcstring)
            {
                if (_pwstStrings[i])
                {
                    wcscpy(_pwstStrings[i], wcstring);
                    _piwLength[i] = (int)wcslen(_pwstStrings[i]);
                }
                else
                {
                    _pwstStrings[i] = NULL;
                    _piwLength[i] = 0;
                }
                FREE(wcstring);
                wcstring = NULL;
            }
            else
            {
                // case to_wide_string fails
                _pwstStrings[i] = NULL;
                _piwLength[i] = 0;
                addErrorMessage(&sciErr, API_ERROR_GET_WIDE_STRING, _("%s: Unable to convert to wide string #%d"), "getMatrixOfWideString", getRhsFromAddress(_pvCtx, _piAddress));
                if (piLenStrings)
                {
                    FREE(piLenStrings);
                    piLenStrings = NULL;
                }
                freeArrayOfString(pstStrings, strSize);
                return sciErr;
            }
        }
        else
        {
            // case to_wide_string fails
            _pwstStrings[i] = NULL;
            _piwLength[i] = 0;
        }
    }

    freeArrayOfString(pstStrings, strSize);
    if (piLenStrings)
    {
        FREE(piLenStrings);
        piLenStrings = NULL;
    }

    return sciErr;
}
/*--------------------------------------------------------------------------*/
SciErr createMatrixOfWideString(void* _pvCtx, int _iVar, int _iRows, int _iCols, const wchar_t* const* _pstwStrings)
{
    char **pStrings = NULL;

    //return empty matrix
    if (_iRows == 0 && _iCols == 0)
    {
        double dblReal = 0;
        SciErr sciErr = createMatrixOfDouble(_pvCtx, _iVar, 0, 0, &dblReal);
        if (sciErr.iErr)
        {
            addErrorMessage(&sciErr, API_ERROR_CREATE_EMPTY_MATRIX, _("%s: Unable to create variable in Scilab memory"), "createEmptyMatrix");
        }
        return sciErr;
    }

    pStrings = (char**)MALLOC( sizeof(char*) * (_iRows * _iCols) );

    for (int i = 0; i < (_iRows * _iCols) ; i++)
    {
        pStrings[i] = wide_string_to_UTF8(_pstwStrings[i]);
    }

    SciErr sciErr = createMatrixOfString(_pvCtx, _iVar, _iRows, _iCols, pStrings);
    if (sciErr.iErr)
    {
        addErrorMessage(&sciErr, API_ERROR_CREATE_WIDE_STRING, _("%s: Unable to create variable in Scilab memory"), "createMatrixOfWideString");
    }

    freeArrayOfString(pStrings, _iRows * _iCols);

    return sciErr;
}
/*--------------------------------------------------------------------------*/
SciErr createNamedMatrixOfWideString(void* _pvCtx, const char* _pstName, int _iRows, int _iCols, const wchar_t* const* _pwstStrings)
{
    char **pStrings = NULL;

    //return named empty matrix
    if (_iRows == 0 && _iCols == 0)
    {
        double dblReal = 0;
        SciErr sciErr = createNamedMatrixOfDouble(_pvCtx, _pstName, 0, 0, &dblReal);
        if (sciErr.iErr)
        {
            addErrorMessage(&sciErr, API_ERROR_CREATE_NAMED_EMPTY_MATRIX, _("%s: Unable to create variable in Scilab memory"), "createNamedEmptyMatrix");
        }
        return sciErr;
    }

    pStrings = (char**)MALLOC( sizeof(char*) * (_iRows * _iCols) );

    for (int i = 0; i < (_iRows * _iCols) ; i++)
    {
        pStrings[i] = wide_string_to_UTF8(_pwstStrings[i]);
    }

    SciErr sciErr = createNamedMatrixOfString(_pvCtx, _pstName, _iRows, _iCols, pStrings);
    freeArrayOfString(pStrings, _iRows * _iCols);
    if (sciErr.iErr)
    {
        addErrorMessage(&sciErr, API_ERROR_CREATE_NAMED_WIDE_STRING, _("%s: Unable to create %s named \"%s\""), "createNamedMatrixOfWideString", _("matrix of wide string"), _pstName);
        return sciErr;
    }

    return sciErr;
}
/*--------------------------------------------------------------------------*/
SciErr readNamedMatrixOfWideString(void* _pvCtx, const char* _pstName, int* _piRows, int* _piCols, int* _piwLength, wchar_t** _pwstStrings)
{
    int* piAddr = NULL;

    SciErr sciErr = getVarAddressFromName(_pvCtx, _pstName, &piAddr);
    if (sciErr.iErr)
    {
        addErrorMessage(&sciErr, API_ERROR_READ_NAMED_WIDE_STRING, _("%s: Unable to get variable \"%s\""), "readNamedMatrixOfWideString", _pstName);
        return sciErr;
    }

    sciErr = getMatrixOfWideString(_pvCtx, piAddr, _piRows, _piCols, _piwLength, _pwstStrings);
    if (sciErr.iErr)
    {
        addErrorMessage(&sciErr, API_ERROR_READ_NAMED_WIDE_STRING, _("%s: Unable to get variable \"%s\""), "readNamedMatrixOfWideString", _pstName);
        return sciErr;
    }

    return sciErr;
}

/*shortcut functions*/
/*--------------------------------------------------------------------------*/
int isStringType(void* _pvCtx, int* _piAddress)
{
    return checkVarType(_pvCtx, _piAddress, sci_strings);
}
/*--------------------------------------------------------------------------*/
int isNamedStringType(void* _pvCtx, const char* _pstName)
{
    return checkNamedVarType(_pvCtx, _pstName, sci_strings);
}
/*--------------------------------------------------------------------------*/
int getAllocatedSingleString(void* _pvCtx, int* _piAddress, char** _pstData)
{
    SciErr sciErr = sciErrInit();
    int iRows = 0;
    int iCols = 0;
    int iLen = 0;

    if (isScalar(_pvCtx, _piAddress) == 0 || isStringType(_pvCtx, _piAddress) == 0)
    {
        addErrorMessage(&sciErr, API_ERROR_GET_ALLOC_SINGLE_STRING, _("%s: Wrong type for input argument #%d: A single string expected.\n"), "getAllocatedSingleString", getRhsFromAddress(_pvCtx, _piAddress));
        printError(&sciErr, 0);
        return sciErr.iErr;
    }

    sciErr = getMatrixOfString(_pvCtx, _piAddress, &iRows, &iCols, &iLen, NULL);
    if (sciErr.iErr)
    {
        addErrorMessage(&sciErr, API_ERROR_GET_ALLOC_SINGLE_STRING, _("%s: Unable to get argument data"), "getAllocatedSingleString");
        printError(&sciErr, 0);
        return sciErr.iErr;
    }

    *_pstData = (char*)MALLOC(sizeof(char) * (iLen + 1)); //+1 for null termination

    sciErr = getMatrixOfString(_pvCtx, _piAddress, &iRows, &iCols, &iLen, _pstData);
    if (sciErr.iErr)
    {
        addErrorMessage(&sciErr, API_ERROR_GET_ALLOC_SINGLE_STRING, _("%s: Unable to get argument data"), "getAllocatedSingleString");
        printError(&sciErr, 0);
        return sciErr.iErr;
    }

    return 0;
}

/*--------------------------------------------------------------------------*/
int getAllocatedSingleWideString(void* _pvCtx, int* _piAddress, wchar_t** _pwstData)
{
    SciErr sciErr = sciErrInit();
    int iRows = 0;
    int iCols = 0;
    int iLen = 0;

    if (isScalar(_pvCtx, _piAddress) == 0 || isStringType(_pvCtx, _piAddress) == 0)
    {
        addErrorMessage(&sciErr, API_ERROR_GET_ALLOC_SINGLE_WIDE_STRING, _("%s: Wrong type for input argument #%d: A single string expected.\n"), "getAllocatedSingleWideString", getRhsFromAddress(_pvCtx, _piAddress));
        printError(&sciErr, 0);
        return sciErr.iErr;
    }

    sciErr = getMatrixOfWideString(_pvCtx, _piAddress, &iRows, &iCols, &iLen, NULL);
    if (sciErr.iErr)
    {
        addErrorMessage(&sciErr, API_ERROR_GET_ALLOC_SINGLE_WIDE_STRING, _("%s: Unable to get argument data"), "getAllocatedSingleWideString");
        printError(&sciErr, 0);
        return sciErr.iErr;
    }

    *_pwstData = (wchar_t*)MALLOC(sizeof(wchar_t) * (iLen + 1)); //+1 for null termination

    sciErr = getMatrixOfWideString(_pvCtx, _piAddress, &iRows, &iCols, &iLen, _pwstData);
    if (sciErr.iErr)
    {
        addErrorMessage(&sciErr, API_ERROR_GET_ALLOC_SINGLE_WIDE_STRING, _("%s: Unable to get argument data"), "getAllocatedSingleWideString");
        printError(&sciErr, 0);
        return sciErr.iErr;
    }

    return 0;
}
/*--------------------------------------------------------------------------*/
int getAllocatedMatrixOfString(void* _pvCtx, int* _piAddress, int* _piRows, int* _piCols, char*** _pstData)
{
    SciErr sciErr = getMatrixOfString(_pvCtx, _piAddress, _piRows, _piCols, NULL, NULL);
    if (sciErr.iErr)
    {
        addErrorMessage(&sciErr, API_ERROR_GET_ALLOC_STRING_MATRIX, _("%s: Unable to get argument data"), "getAllocatedMatrixOfString");
        printError(&sciErr, 0);
        return sciErr.iErr;
    }

    int* piLen = (int*)MALLOC(sizeof(int) **_piRows **_piCols);
    *_pstData = (char**)MALLOC(sizeof(char*) **_piRows **_piCols);

    sciErr = getMatrixOfString(_pvCtx, _piAddress, _piRows, _piCols, piLen, NULL);
    if (sciErr.iErr)
    {
        addErrorMessage(&sciErr, API_ERROR_GET_ALLOC_STRING_MATRIX, _("%s: Unable to get argument data"), "getAllocatedMatrixOfString");
        printError(&sciErr, 0);
        if (piLen)
        {
            FREE(piLen);
            piLen = NULL;
        }
        return sciErr.iErr;
    }

    for (int i = 0 ; i < *_piRows **_piCols ; i++)
    {
        (*_pstData)[i] = (char*)MALLOC(sizeof(char) * (piLen[i] + 1));//+1 for null termination
    }

    sciErr = getMatrixOfString(_pvCtx, _piAddress, _piRows, _piCols, piLen, *_pstData);
    if (piLen)
    {
        FREE(piLen);
        piLen = NULL;
    }
    if (sciErr.iErr)
    {
        addErrorMessage(&sciErr, API_ERROR_GET_ALLOC_STRING_MATRIX, _("%s: Unable to get argument data"), "getAllocatedMatrixOfString");
        printError(&sciErr, 0);
        return sciErr.iErr;
    }

    return 0;
}
/*--------------------------------------------------------------------------*/
int getAllocatedMatrixOfWideString(void* _pvCtx, int* _piAddress, int* _piRows, int* _piCols, wchar_t*** _pwstData)
{
    SciErr sciErr = getMatrixOfWideString(_pvCtx, _piAddress, _piRows, _piCols, NULL, NULL);
    if (sciErr.iErr)
    {
        addErrorMessage(&sciErr, API_ERROR_GET_ALLOC_WIDE_STRING_MATRIX, _("%s: Unable to get argument data"), "getAllocatedMatrixOfWideString");
        printError(&sciErr, 0);
        return sciErr.iErr;
    }

    int* piLen = (int*)MALLOC(sizeof(int) **_piRows **_piCols);
    *_pwstData = (wchar_t**)MALLOC(sizeof(wchar_t*) **_piRows **_piCols);

    sciErr = getMatrixOfWideString(_pvCtx, _piAddress, _piRows, _piCols, piLen, NULL);
    if (sciErr.iErr)
    {
        addErrorMessage(&sciErr, API_ERROR_GET_ALLOC_WIDE_STRING_MATRIX, _("%s: Unable to get argument data"), "getAllocatedMatrixOfWideString");
        if (piLen)
        {
            FREE(piLen);
            piLen = NULL;
        }
        printError(&sciErr, 0);
        return sciErr.iErr;
    }

    for (int i = 0 ; i < *_piRows **_piCols ; i++)
    {
        (*_pwstData)[i] = (wchar_t*)MALLOC(sizeof(wchar_t) * (piLen[i] + 1));//+1 for null termination
    }

    sciErr = getMatrixOfWideString(_pvCtx, _piAddress, _piRows, _piCols, piLen, *_pwstData);

    if (piLen)
    {
        FREE(piLen);
        piLen = NULL;
    }

    if (sciErr.iErr)
    {
        addErrorMessage(&sciErr, API_ERROR_GET_ALLOC_WIDE_STRING_MATRIX, _("%s: Unable to get argument data"), "getAllocatedMatrixOfWideString");
        printError(&sciErr, 0);
        return sciErr.iErr;
    }
    return 0;
}
/*--------------------------------------------------------------------------*/
int getAllocatedNamedSingleString(void* _pvCtx, const char* _pstName, char** _pstData)
{
    SciErr sciErr = sciErrInit();
    int iRows = 0;
    int iCols = 0;
    int iLen = 0;

    if (isNamedScalar(_pvCtx, _pstName) == 0 || isNamedStringType(_pvCtx, _pstName) == 0)
    {
        addErrorMessage(&sciErr, API_ERROR_GET_ALLOC_NAMED_SINGLE_STRING, _("%s: Wrong type for input argument \"%s\": A single string expected.\n"), "getAllocatedNamedSingleString", _pstName);
        printError(&sciErr, 0);
        return sciErr.iErr;
    }

    sciErr = readNamedMatrixOfString(_pvCtx, _pstName, &iRows, &iCols, &iLen, NULL);
    if (sciErr.iErr)
    {
        addErrorMessage(&sciErr, API_ERROR_GET_ALLOC_NAMED_SINGLE_STRING, _("%s: Unable to get argument data"), "getAllocatedNamedSingleString");
        printError(&sciErr, 0);
        return sciErr.iErr;
    }

    *_pstData = (char*)MALLOC(sizeof(char) * (iLen + 1)); //+1 for null termination

    sciErr = readNamedMatrixOfString(_pvCtx, _pstName, &iRows, &iCols, &iLen, _pstData);
    if (sciErr.iErr)
    {
        addErrorMessage(&sciErr, API_ERROR_GET_ALLOC_NAMED_SINGLE_STRING, _("%s: Unable to get argument data"), "getAllocatedNamedSingleString");
        printError(&sciErr, 0);
        return sciErr.iErr;
    }

    return 0;
}
/*--------------------------------------------------------------------------*/
int getAllocatedNamedSingleWideString(void* _pvCtx, const char* _pstName, wchar_t** _pwstData)
{
    SciErr sciErr = sciErrInit();
    int iRows = 0;
    int iCols = 0;
    int iLen = 0;

    if (isNamedScalar(_pvCtx, _pstName) == 0 || isNamedStringType(_pvCtx, _pstName) == 0)
    {
        addErrorMessage(&sciErr, API_ERROR_GET_ALLOC_NAMED_SINGLE_WIDE_STRING, _("%s: Wrong type for input argument \"%s\": A single string expected.\n"), "getAllocatedNamedSingleWideString", _pstName);
        printError(&sciErr, 0);
        return sciErr.iErr;
    }

    sciErr = readNamedMatrixOfWideString(_pvCtx, _pstName, &iRows, &iCols, &iLen, NULL);
    if (sciErr.iErr)
    {
        addErrorMessage(&sciErr, API_ERROR_GET_ALLOC_NAMED_SINGLE_WIDE_STRING, _("%s: Unable to get argument data"), "getAllocatedNamedSingleWideString");
        printError(&sciErr, 0);
        return sciErr.iErr;
    }

    *_pwstData = (wchar_t*)MALLOC(sizeof(wchar_t) * (iLen + 1)); //+1 for null termination

    sciErr = readNamedMatrixOfWideString(_pvCtx, _pstName, &iRows, &iCols, &iLen, _pwstData);
    if (sciErr.iErr)
    {
        addErrorMessage(&sciErr, API_ERROR_GET_ALLOC_NAMED_SINGLE_WIDE_STRING, _("%s: Unable to get argument data"), "getAllocatedNamedSingleWideString");
        printError(&sciErr, 0);
        return sciErr.iErr;
    }

    return 0;
}
/*--------------------------------------------------------------------------*/
int getAllocatedNamedMatrixOfString(void* _pvCtx, const char* _pstName, int* _piRows, int* _piCols, char*** _pstData)
{
    SciErr sciErr = readNamedMatrixOfString(_pvCtx, _pstName, _piRows, _piCols, NULL, NULL);
    if (sciErr.iErr)
    {
        addErrorMessage(&sciErr, API_ERROR_GET_ALLOC_NAMED_STRING_MATRIX, _("%s: Unable to get argument data"), "getAllocatedNamedMatrixOfString");
        printError(&sciErr, 0);
        return sciErr.iErr;
    }

    int* piLen = (int*)MALLOC(sizeof(int) **_piRows **_piCols);

    sciErr = readNamedMatrixOfString(_pvCtx, _pstName, _piRows, _piCols, piLen, NULL);
    if (sciErr.iErr)
    {
        addErrorMessage(&sciErr, API_ERROR_GET_ALLOC_NAMED_STRING_MATRIX, _("%s: Unable to get argument data"), "getAllocatedNamedMatrixOfString");
        if (piLen)
        {
            FREE(piLen);
            piLen = NULL;
        }
        printError(&sciErr, 0);
        return sciErr.iErr;
    }

    *_pstData = (char**)MALLOC(sizeof(char*) **_piRows **_piCols);
    for (int i = 0 ; i < *_piRows **_piCols ; i++)
    {
        (*_pstData)[i] = (char*)MALLOC(sizeof(char) * (piLen[i] + 1));//+1 for null termination
    }

    sciErr = readNamedMatrixOfString(_pvCtx, _pstName, _piRows, _piCols, piLen, *_pstData);
    if (piLen)
    {
        FREE(piLen);
        piLen = NULL;
    }
    if (sciErr.iErr)
    {
        addErrorMessage(&sciErr, API_ERROR_GET_ALLOC_NAMED_STRING_MATRIX, _("%s: Unable to get argument data"), "getAllocatedNamedMatrixOfString");
        printError(&sciErr, 0);
        return sciErr.iErr;
    }

    return 0;
}
/*--------------------------------------------------------------------------*/
int getAllocatedNamedMatrixOfWideString(void* _pvCtx, const char* _pstName, int* _piRows, int* _piCols, wchar_t*** _pwstData)
{
    int iRows = 0;
    int iCols = 0;
    int* piLen = 0;

    SciErr sciErr = readNamedMatrixOfWideString(_pvCtx, _pstName, &iRows, &iCols, NULL, NULL);
    if (sciErr.iErr)
    {
        addErrorMessage(&sciErr, API_ERROR_GET_ALLOC_NAMED_WIDE_STRING_MATRIX, _("%s: Unable to get argument data"), "getAllocatedNamedMatrixOfWideString");
        printError(&sciErr, 0);
        return sciErr.iErr;
    }

    piLen = (int*)MALLOC(sizeof(int) **_piRows **_piCols);

    sciErr = readNamedMatrixOfWideString(_pvCtx, _pstName, &iRows, &iCols, piLen, NULL);
    if (sciErr.iErr)
    {
        addErrorMessage(&sciErr, API_ERROR_GET_ALLOC_NAMED_WIDE_STRING_MATRIX, _("%s: Unable to get argument data"), "getAllocatedNamedMatrixOfWideString");
        if (piLen)
        {
            FREE(piLen);
            piLen = NULL;
        }
        printError(&sciErr, 0);
        return sciErr.iErr;
    }

    *_pwstData = (wchar_t**)MALLOC(sizeof(wchar_t*) **_piRows **_piCols);

    for (int i = 0 ; i < *_piRows **_piCols ; i++)
    {
        *_pwstData[i] = (wchar_t*)MALLOC(sizeof(wchar_t) * (piLen[i] + 1));//+1 for null termination
    }

    sciErr = readNamedMatrixOfWideString(_pvCtx, _pstName, &iRows, &iCols, piLen, *_pwstData);
    if (piLen)
    {
        FREE(piLen);
        piLen = NULL;
    }
    if (sciErr.iErr)
    {
        addErrorMessage(&sciErr, API_ERROR_GET_ALLOC_NAMED_WIDE_STRING_MATRIX, _("%s: Unable to get argument data"), "getAllocatedNamedMatrixOfWideString");
        printError(&sciErr, 0);
        return sciErr.iErr;
    }

    return 0;
}
/*--------------------------------------------------------------------------*/
int createSingleString(void* _pvCtx, int _iVar, const char* _pstStrings)
{
    SciErr sciErr = createMatrixOfString(_pvCtx, _iVar, 1, 1,	&_pstStrings);
    if (sciErr.iErr)
    {
        addErrorMessage(&sciErr, API_ERROR_CREATE_SINGLE_STRING, _("%s: Unable to get argument data"), "createSingleString");
        printError(&sciErr, 0);
        return sciErr.iErr;
    }

    return 0;
}

int allocSingleString(void* _pvCtx, int _iVar, int _iLen, const char** _pstStrings)
{
    SciErr sciErr = sciErrInit();
    int iNewPos     = Top - Rhs + _iVar;
    int iAddr       = *Lstk(iNewPos);
    int iTotalLen   = 0;
    int* piAddr     = NULL;
    int* piOffset   = NULL;
    char* pstString = NULL;

    int iFreeSpace = iadr(*Lstk(Bot)) - (iadr(*Lstk(Top)));

    if (_iLen + 2 > iFreeSpace)
    {
        addStackSizeError(&sciErr, ((StrCtx*)_pvCtx)->pstName, _iLen + 2);
        return sciErr.iErr;
    }

    getNewVarAddressFromPosition(_pvCtx, iNewPos, &piAddr);

    piAddr[0]   = sci_strings;
    piAddr[1]   = 1;
    piAddr[2]   = 1;
    piAddr[3]   = 0;

    piOffset    = piAddr + 4;
    piOffset[0] = 1; //Always 1
    piOffset[1] = _iLen + 1;
    pstString   = (char*)(piOffset + 2); //2 offsets

    // Fill the string with spaces
    memset(pstString, ' ', _iLen);

    updateInterSCI(_iVar, 'c', iAddr, cadr(iadr(iAddr) + 5 + 1));
    updateLstk(iNewPos, sadr(iadr(iAddr) + 5 + 1), (_iLen + 1) / (sizeof(double) / sizeof(int)));
    *_pstStrings = pstString;
    return 0;
}

/*--------------------------------------------------------------------------*/
int createSingleWideString(void* _pvCtx, int _iVar, const wchar_t* _pwstStrings)
{
    SciErr sciErr = createMatrixOfWideString(_pvCtx, _iVar, 1, 1,	&_pwstStrings);
    if (sciErr.iErr)
    {
        addErrorMessage(&sciErr, API_ERROR_CREATE_SINGLE_WIDE_STRING, _("%s: Unable to get argument data"), "createSingleWideString");
        printError(&sciErr, 0);
        return sciErr.iErr;
    }

    return 0;
}
/*--------------------------------------------------------------------------*/
int createNamedSingleString(void* _pvCtx, const char* _pstName, const char* _pstStrings)
{
    SciErr sciErr = createNamedMatrixOfString(_pvCtx, _pstName, 1, 1,	&_pstStrings);
    if (sciErr.iErr)
    {
        addErrorMessage(&sciErr, API_ERROR_CREATE_NAMED_SINGLE_STRING, _("%s: Unable to get argument data"), "createSingleString");
        printError(&sciErr, 0);
        return sciErr.iErr;
    }

    return 0;
}
/*--------------------------------------------------------------------------*/
int createNamedSingleWideString(void* _pvCtx, const char* _pstName, const wchar_t* _pwstStrings)
{
    SciErr sciErr = createNamedMatrixOfWideString(_pvCtx, _pstName, 1, 1,	&_pwstStrings);
    if (sciErr.iErr)
    {
        addErrorMessage(&sciErr, API_ERROR_CREATE_NAMED_SINGLE_WIDE_STRING, _("%s: Unable to get argument data"), "createSingleWideString");
        printError(&sciErr, 0);
        return sciErr.iErr;
    }

    return 0;
}
/*--------------------------------------------------------------------------*/
void freeAllocatedSingleString(char* _pstData)
{
    FREE(_pstData);
}
/*--------------------------------------------------------------------------*/
void freeAllocatedSingleWideString(wchar_t* _pwstData)
{
    FREE(_pwstData);
}
/*--------------------------------------------------------------------------*/
void freeAllocatedMatrixOfString(int _iRows, int _iCols, char** _pstData)
{
    for (int i = 0 ; i < _iRows * _iCols ; i++)
    {
        FREE(_pstData[i]);
    }
    FREE(_pstData);
}
/*--------------------------------------------------------------------------*/
void freeAllocatedMatrixOfWideString(int _iRows, int _iCols, wchar_t** _pwstData)
{
    for (int i = 0 ; i < _iRows * _iCols ; i++)
    {
        FREE(_pwstData[i]);
    }
    FREE(_pwstData);
}
/*--------------------------------------------------------------------------*/
