*     various constant used in somespline.f
      integer    NOT_A_KNOT,   NATURAL,   CLAMPED,   PERIODIC     
      parameter (NOT_A_KNOT=0, NATURAL=1, CLAMPED=2, PERIODIC=3) 
      integer    FAST,   FAST_PERIODIC,   MONOTONE,   BY_ZERO 
      parameter (FAST=4, FAST_PERIODIC=5, MONOTONE=6, BY_ZERO=7)
      integer    C0,   LINEAR,    BY_NAN
      parameter (C0=8, LINEAR=9,  BY_NAN=10)

