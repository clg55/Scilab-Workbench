/* Copyright (C) 1998 Chancelier Jean-Philippe */

#include <stdio.h>

main()
{
  char *poo;
  poo = "12345";
  fprintf(stderr,"[%c]",*poo++);
};

eventloop
123
