/* Copyright ENPC */

#include "men_scilab.h"

/*****************************************************************
 * generic function used for all the Scilab transient `menus' 
 *****************************************************************/
