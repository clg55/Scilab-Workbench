int get_1byte_value( char *start );
int get_2byte_value( char *start );
int get_4byte_value( char *start );
