Only for Windows.
Copy bin,lib and site directories of Perl in this directory.