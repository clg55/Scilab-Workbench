Install OCaml from www.ocaml.org
Edit Makefile.mak and modify first line with a correct path

OCAMLPATH=C:\Program Files\Objective Caml

