#ifndef __INIT_UIMENU_HXX__
#define __INIT_UIMENU_HXX__

extern "C"
{
  #include "InitUIMenu.h"
}

#endif
