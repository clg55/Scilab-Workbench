----------------
Prerequirements:
----------------

* Visual Studio C++ .NET 2011 Pro
* Intel Fortran 2011 XE update 1 (or more)

or

* Visual Studio C++ .NET 2010 Express

Please read http://wiki.scilab.org/Build_Scilab_with_Visual_Studio_2010 for more information


