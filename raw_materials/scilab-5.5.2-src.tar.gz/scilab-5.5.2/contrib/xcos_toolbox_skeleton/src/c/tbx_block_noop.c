/* This file is released under the 3-clause BSD license. See COPYING-BSD. */

#include <scicos_block4.h>

void tbx_block_noop(scicos_block* block, scicos_flag flag)
{
}

