//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by Setup.rc
//
#define IDD_INSTALL                     101
#define IDI_SCE                         103
#define IDI_SCI                         104
#define IDI_SCILAB                      105
#define IDI_TST                         106
#define IDI_BIN                         107
#define IDI_COS                         108
#define IDI_COSF                        109
#define IDI_DEM                         110
#define IDI_GRAPH                       111
#define IDI_SAV                         112
#define IDB_BITMAP1                     113
#define IDB_LOGO                        113
#define IDC_CHECKSCI                    1001
#define IDC_CHECKSCE                    1002
#define IDC_CHECKTST                    1003
#define IDC_CHECKDEM                    1004
#define IDC_CHECKCOS                    1005
#define IDC_CHECKCOSF                   1006
#define IDC_CHECKBIN                    1007
#define IDC_CHECKSAV                    1008
#define IDC_CHECKGRAPH                  1009
#define IDC_CHECKGRAPHB                 1010
#define IDC_STATICICONSCI               1011
#define IDC_STATICICONSCE               1012
#define IDC_STATICICONTST               1013
#define IDC_STATICICONDEM               1014
#define IDC_STATICICONCOS               1015
#define IDC_STATICICONCOSF              1016
#define IDC_STATICICONBIN               1017
#define IDC_STATICICONSAV               1018
#define IDC_STATICICONGRAPH             1019
#define IDC_STATICICONGRAPHB            1020
#define IDC_STATICCADRE                 1021
#define IDC_STATICTEXT                  1022
#define IDC_STATICSCILAB                1023

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        114
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1024
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
